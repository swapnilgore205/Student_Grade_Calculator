document.getElementById("gradeForm").addEventListener("submit", function(e) {
    e.preventDefault();
    
    let name = document.getElementById("name").value;
    let roll = parseInt(document.getElementById("roll").value);
    let s1 = parseInt(document.getElementById("subject1").value);
    let s2 = parseInt(document.getElementById("subject2").value);
    let s3 = parseInt(document.getElementById("subject3").value);
    
    let total = s1 + s2 + s3;
    let average = total / 3;
    let grade = "";

    if (average >= 90) grade = "A+";
    else if (average >= 80) grade = "A";
    else if (average >= 70) grade = "B";
    else if (average >= 60) grade = "C";
    else if (average >= 50) grade = "D";
    else grade = "F (Fail)";

    document.getElementById("result").innerHTML = 
        "<p>Name: " + name + "</p>" +
        "<p>Roll No: " + roll + "</p>" +
        "<p>Total: " + total + "</p>" +
        "<p>Average: " + average.toFixed(2) + "</p>" +
        "<p>Grade: " + grade + "</p>";
});
